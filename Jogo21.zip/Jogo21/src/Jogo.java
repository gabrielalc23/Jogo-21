
import java.awt.Dimension;
import java.awt.Image;
import java.util.HashSet;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Jogo extends javax.swing.JFrame {

    public Jogo() {
        initComponents();
        iniciaJogo();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        CartaAtual = new javax.swing.JLabel();
        CartaCPU = new javax.swing.JLabel();
        CartaJogador = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        BtPegar = new javax.swing.JButton();
        BtParar = new javax.swing.JButton();
        ResultadosAnteriores = new javax.swing.JLabel();
        txtPontosCPU = new javax.swing.JLabel();
        txtPontosJogador = new javax.swing.JLabel();
        txtParadaJogador = new javax.swing.JLabel();
        txtParadaCPU = new javax.swing.JLabel();
        BtRecomecar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Jogo 21");
        setResizable(false);

        CartaAtual.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        CartaCPU.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        CartaJogador.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setText("Jogador:");

        jLabel3.setText("CPU:");

        BtPegar.setBackground(new java.awt.Color(0, 204, 51));
        BtPegar.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        BtPegar.setText("Pegar Carta");
        BtPegar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtPegarActionPerformed(evt);
            }
        });

        BtParar.setBackground(new java.awt.Color(255, 51, 51));
        BtParar.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        BtParar.setText("Parar");
        BtParar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtPararActionPerformed(evt);
            }
        });

        ResultadosAnteriores.setText("Resultados Anteriores:");
        ResultadosAnteriores.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        ResultadosAnteriores.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtPontosCPU.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        txtPontosCPU.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtPontosCPU.setText("  ");
        txtPontosCPU.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtPontosJogador.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        txtPontosJogador.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtPontosJogador.setText("  ");
        txtPontosJogador.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtParadaJogador.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtParadaJogador.setForeground(new java.awt.Color(255, 0, 0));
        txtParadaJogador.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        txtParadaCPU.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtParadaCPU.setForeground(new java.awt.Color(255, 102, 153));

        BtRecomecar.setBackground(new java.awt.Color(0, 153, 255));
        BtRecomecar.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        BtRecomecar.setText("Recomeçar");
        BtRecomecar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtRecomecarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BtRecomecar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BtPegar, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel2)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(CartaAtual, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(33, 33, 33)
                                                .addComponent(jLabel3))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(18, 18, 18)
                                                .addComponent(txtPontosJogador, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(txtPontosCPU, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(txtParadaJogador, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                    .addComponent(txtParadaCPU, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(CartaJogador, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(CartaCPU, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ResultadosAnteriores, javax.swing.GroupLayout.DEFAULT_SIZE, 153, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(BtParar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(ResultadosAnteriores, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(CartaAtual, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(CartaJogador, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtPontosJogador)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtParadaJogador, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtPontosCPU, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtParadaCPU, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(CartaCPU, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BtPegar, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtParar, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(BtRecomecar, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    int[] numeroCarta = new int[52];    // posição da carta no array
    String[] imagemCarta = new String[52]; // imagem da carta
    int[] pontosCartas = new int[52];    // quanto vale a carta
    int posicaoCartinhaJogador; // posição das cartinhas que o jogador tem
    int posicaoCartinhaCPU;     // posição das cartinhas que a CPU tem
    int pontosJogador, pontosCPU; // pontos do jogador e da CPU
    String resultadoAnterior = "";      // último resultado;
    JLabel cartinhasCPUTemp = new JLabel("");
    int reiniciaJogo = 0;

    public void iniciaJogo() {
        // Limpando os pontos
        BtRecomecar.setEnabled(false);
        pontosJogador = 0;
        pontosCPU = 0;
        txtPontosJogador.setText("0");
        txtPontosCPU.setText("0");
        txtParadaCPU.setText("");
        txtParadaJogador.setText("");
        cartinhasCPUTemp = new JLabel("");
        
        // Limpar a CartaAtual e as Cartinhas (CPU e Jogador)
        CartaAtual.setIcon(null);
        CartaJogador.removeAll();
        CartaJogador.repaint();
        CartaCPU.removeAll();
        CartaCPU.repaint();

        // Limpar a posição da cartinha nas listas cartaCPU e cartaJogador
        posicaoCartinhaCPU = 0;
        posicaoCartinhaJogador = 0;

        // Como a variável numeroCarta controla as cartas que já foram viradas ou não
        // preciso zerar TODAS as 52 cartas, pois quando for 1, é porque ela foi virada
        for (int cont = 0; cont <= 51; cont++) {
            // começo em 0; vou até 51; aumentando de um em um (++)
            numeroCarta[cont] = 0;
        }

        // Inserir o caminho da imagem de TODAS as cartas...
        imagemCarta[0] = "AO.jpg";
        imagemCarta[1] = "AE.jpg";
        imagemCarta[2] = "AC.jpg";
        imagemCarta[3] = "AP.jpg";

        imagemCarta[4] = "2O.jpg";
        imagemCarta[5] = "2E.jpg";
        imagemCarta[6] = "2C.jpg";
        imagemCarta[7] = "2P.jpg";

        imagemCarta[8] = "3O.jpg";
        imagemCarta[9] = "3E.jpg";
        imagemCarta[10] = "3C.jpg";
        imagemCarta[11] = "3P.jpg";

        imagemCarta[12] = "4O.jpg";
        imagemCarta[13] = "4E.jpg";
        imagemCarta[14] = "4C.jpg";
        imagemCarta[15] = "4P.jpg";

        imagemCarta[16] = "5O.jpg";
        imagemCarta[17] = "5E.jpg";
        imagemCarta[18] = "5C.jpg";
        imagemCarta[19] = "5P.jpg";

        imagemCarta[20] = "6O.jpg";
        imagemCarta[21] = "6E.jpg";
        imagemCarta[22] = "6C.jpg";
        imagemCarta[23] = "6P.jpg";

        imagemCarta[24] = "7O.jpg";
        imagemCarta[25] = "7E.jpg";
        imagemCarta[26] = "7C.jpg";
        imagemCarta[27] = "7P.jpg";

        imagemCarta[28] = "8O.jpg";
        imagemCarta[29] = "8E.jpg";
        imagemCarta[30] = "8C.jpg";
        imagemCarta[31] = "8P.jpg";

        imagemCarta[32] = "9O.jpg";
        imagemCarta[33] = "9E.jpg";
        imagemCarta[34] = "9C.jpg";
        imagemCarta[35] = "9P.jpg";

        imagemCarta[36] = "10O.jpg";
        imagemCarta[37] = "10E.jpg";
        imagemCarta[38] = "10C.jpg";
        imagemCarta[39] = "10P.jpg";

        imagemCarta[40] = "QO.jpg";
        imagemCarta[41] = "QE.jpg";
        imagemCarta[42] = "QC.jpg";
        imagemCarta[43] = "QP.jpg";

        imagemCarta[44] = "JO.jpg";
        imagemCarta[45] = "JE.jpg";
        imagemCarta[46] = "JC.jpg";
        imagemCarta[47] = "JP.jpg";

        imagemCarta[48] = "KO.jpg";
        imagemCarta[49] = "KE.jpg";
        imagemCarta[50] = "KC.jpg";
        imagemCarta[51] = "KP.jpg";

        pontosCartas[0] = 1;
        pontosCartas[1] = 1;
        pontosCartas[2] = 1;
        pontosCartas[3] = 1;

        pontosCartas[4] = 2;
        pontosCartas[5] = 2;
        pontosCartas[6] = 2;
        pontosCartas[7] = 2;

        pontosCartas[8] = 3;
        pontosCartas[9] = 3;
        pontosCartas[10] = 3;
        pontosCartas[11] = 3;

        pontosCartas[12] = 4;
        pontosCartas[13] = 4;
        pontosCartas[14] = 4;
        pontosCartas[15] = 4;

        pontosCartas[16] = 5;
        pontosCartas[17] = 5;
        pontosCartas[18] = 5;
        pontosCartas[19] = 5;

        pontosCartas[20] = 6;
        pontosCartas[21] = 6;
        pontosCartas[22] = 6;
        pontosCartas[23] = 6;

        pontosCartas[24] = 7;
        pontosCartas[25] = 7;
        pontosCartas[26] = 7;
        pontosCartas[27] = 7;

        pontosCartas[28] = 8;
        pontosCartas[29] = 8;
        pontosCartas[30] = 8;
        pontosCartas[31] = 8;

        pontosCartas[32] = 9;
        pontosCartas[33] = 9;
        pontosCartas[34] = 9;
        pontosCartas[35] = 9;

        pontosCartas[36] = 10;
        pontosCartas[37] = 10;
        pontosCartas[38] = 10;
        pontosCartas[39] = 10;

        pontosCartas[40] = 10;
        pontosCartas[41] = 10;
        pontosCartas[42] = 10;
        pontosCartas[43] = 10;

        pontosCartas[44] = 10;
        pontosCartas[45] = 10;
        pontosCartas[46] = 10;
        pontosCartas[47] = 10;

        pontosCartas[48] = 10;
        pontosCartas[49] = 10;
        pontosCartas[50] = 10;
        pontosCartas[51] = 10;
    }

    private void BtPegarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtPegarActionPerformed

        // pegar aleatoriamente uma carta
       
        
            Random puxar = new Random();
            int numRandom;
            do {
                numRandom = puxar.nextInt(52);
            } while (numeroCarta[numRandom] == 1);

            //colocar a imagem na tela
            ImageIcon puxarCarta = new ImageIcon("CartasBaralho\\" + imagemCarta[numRandom]);
            CartaAtual.setIcon(puxarCarta);

            //gera a miniatura
            Image miniCarta = puxarCarta.getImage().getScaledInstance(46, 61, java.awt.Image.SCALE_SMOOTH);
            // largura, altura, proporção
            puxarCarta = new ImageIcon(miniCarta);

            // cria DINAMICAMENTE uma lista de imagens para colocar na tela
            JLabel miniatura = new JLabel("");
            miniatura.setIcon(puxarCarta);

            // coloca uma miniatura ao lado da outra (largura 62, altura 81)
            // cada cartinha ocupa 46 (pixels) na horizontal
            int localHorizontal = ((posicaoCartinhaJogador++ * 46) + 2);
            // quando pular de linha, reseta a horizontal
            int localVertical;
            if (posicaoCartinhaJogador > 5) {
                // Gambiarra - Quando pular de linha, ele volta 310px para trás
                localHorizontal = localHorizontal - 230;
                // a partir da 6a cartinha, ele coloca na linha 83 (em pixels)
                localVertical = 62;
            } else {
                localVertical = 2;
            }
            miniatura.setLocation(localHorizontal, localVertical);

            //redimensiona o tamanho das cartinhas, pois elas estão
            miniatura.setSize(new Dimension(46, 60));
            if (pontosJogador < 21) {
            //adiciona as cartinhas na tela e atualiza a tela para mostrar
            CartaJogador.add(miniatura);
            CartaJogador.repaint();

            // Trava para não pegar carta repetida
            numeroCarta[numRandom] = 1;

            // Calcula os pontos do jogador
            pontosJogador += pontosCartas[numRandom];
   
            txtPontosJogador.setText(String.valueOf(pontosJogador));
            
            // Chamar a função para a CPU pegar uma carta
            pegaCartaCPU();
        } else {
        pararJogo();
        BtPegar.setEnabled(false);
        }
        
    }//GEN-LAST:event_BtPegarActionPerformed
        
     public void pegaCartaCPU() {

        if (pontosCPU < 18) {
            Random puxar = new Random();
            int numRandom;
            do {
                numRandom = puxar.nextInt(52);
            } while (numeroCarta[numRandom] == 1);

            //colocar a imagem na tela
            ImageIcon puxarCarta = new ImageIcon("CartasBaralho\\" + imagemCarta[numRandom]);

            //gera a miniatura
            Image miniCarta = puxarCarta.getImage().getScaledInstance(46, 61, java.awt.Image.SCALE_SMOOTH);
            // largura, altura, proporção
            puxarCarta = new ImageIcon(miniCarta);

            // cria DINAMICAMENTE uma lista de imagens para colocar na tela
            JLabel miniatura = new JLabel("");
            miniatura.setIcon(puxarCarta);

            // coloca uma miniatura ao lado da outra (largura 62, altura 81)
            // cada cartinha ocupa 46 (pixels) na horizontal
            int localHorizontal = ((posicaoCartinhaCPU++ * 46) + 2);
            // quando pular de linha, reseta a horizontal
            int localVertical;
            if (posicaoCartinhaCPU > 5) {
                // Gambiarra - Quando pular de linha, ele volta 310px para trás
                localHorizontal = localHorizontal - 230;
                // a partir da 6a cartinha, ele coloca na linha 83 (em pixels)
                localVertical = 62;
            } else {
                localVertical = 2;
            }
            miniatura.setLocation(localHorizontal, localVertical);

            //redimensiona o tamanho das cartinhas, pois elas estão
            miniatura.setSize(new Dimension(46, 60));

            //adiciona as cartinhas na tela e atualiza a tela para mostrar
            cartinhasCPUTemp.add(miniatura);
            cartinhasCPUTemp.repaint();

            // Trava para não pegar carta repetida
            numeroCarta[numRandom] = 1;

            // Calcula os pontos do jogador
            pontosCPU += pontosCartas[numRandom];
            txtPontosCPU.setText("?");

        }
        else {
        txtParadaCPU.setText("X");
        }
    }
    private void BtPararActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtPararActionPerformed
        pararJogo();
    }//GEN-LAST:event_BtPararActionPerformed

    private void BtRecomecarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtRecomecarActionPerformed
         iniciaJogo();
         BtPegar.setEnabled(true);
         BtParar.setEnabled(true);
         
    }//GEN-LAST:event_BtRecomecarActionPerformed
    public void pararJogo(){
        while (pontosCPU < 18) {
        pegaCartaCPU();
        }
        
    cartinhasCPUTemp.setLocation(0, 0);
        cartinhasCPUTemp.setSize(new Dimension(235, 125));

        CartaCPU.add(cartinhasCPUTemp);
        CartaCPU.repaint();
        
        txtParadaCPU.setText("PARÔÔÔ");
        txtParadaJogador.setText("PAREEEI");
        txtPontosCPU.setText(String.valueOf(pontosCPU));
        
        txtPontosCPU.setText(String.valueOf(pontosCPU));
        BtPegar.setEnabled(false);
        BtParar.setEnabled(false);
        verificarGanhador();
        resultadoAnterior = resultadoAnterior + "<BR>Jogador: " + pontosJogador + "\n" + " - CPU: " + pontosCPU;
        ResultadosAnteriores.setText("<HTML>Resultados Anteriores:" + resultadoAnterior + "</HTML>");
    }
   
    public void verificarGanhador(){
    
        if (pontosJogador > pontosCPU && pontosJogador <= 21 || pontosCPU > 21 && pontosJogador <= 21){
        JOptionPane.showMessageDialog(rootPane,"O jogador venceu com " + pontosJogador);
        } else if (pontosCPU > pontosJogador && pontosCPU <= 21 || pontosJogador > 21 && pontosCPU <= 21){
        JOptionPane.showMessageDialog(rootPane,"A CPU venceu com " + pontosCPU);
        } else if (pontosJogador < pontosCPU && pontosJogador > 21 && pontosCPU > 21){
        JOptionPane.showMessageDialog(rootPane,"O jogador estourou, mas venceu com " + pontosJogador);
        } else if (pontosCPU < pontosJogador && pontosCPU > 21 && pontosJogador > 21 && pontosCPU > 21){
        JOptionPane.showMessageDialog(rootPane,"O CPU estourou, mas venceu com " + pontosCPU);
        } else if (pontosCPU == pontosJogador){
        JOptionPane.showMessageDialog(rootPane,"Empate: " + pontosCPU);}
        else {
         JOptionPane.showMessageDialog(rootPane,"Teste: " + pontosCPU);
        }
        BtRecomecar.setEnabled(true);
        
        
    }

    
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Jogo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Jogo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Jogo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Jogo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Jogo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtParar;
    private javax.swing.JButton BtPegar;
    private javax.swing.JButton BtRecomecar;
    private javax.swing.JLabel CartaAtual;
    private javax.swing.JLabel CartaCPU;
    private javax.swing.JLabel CartaJogador;
    private javax.swing.JLabel ResultadosAnteriores;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel txtParadaCPU;
    private javax.swing.JLabel txtParadaJogador;
    private javax.swing.JLabel txtPontosCPU;
    private javax.swing.JLabel txtPontosJogador;
    // End of variables declaration//GEN-END:variables
}
